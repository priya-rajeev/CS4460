// JavaScript code goes here
thronesCharacters = [{
            "name": "Arya Stark",
            "status": "Alive",
            "current_location" : "Sailing uncharted seas",
            "house" : "Stark",
            "probability_of_survival" : 99  
},
{
            "name" : "Tyrion Lannister",
            "status" : "Alive",
            "current_location" : "Casterly Rock",
            "house" : "Lannnister",
            "probability_of_survival" : 88
},
{
            "name" : "Daenerys Targaryen",
            "status" : "Dead",
            "current_location" : "n/a",
            "house" : "Targaryen",
            "probability_of_survival" : 0
},
{           "name" : "Jon Snow",
            "status" : "Alive",
            "current_location" : "The Wall",
            "house" : "Night's Watch",
            "probability_of_survival" : 50

}
]
console.log(thronesCharacters)