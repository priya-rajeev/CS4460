// **** Example of how to create padding and spacing for trellis plot****
var svg = d3.select('svg');

// Hand code the svg dimensions, you can also use +svg.attr('width') or +svg.attr('height')
var svgWidth = +svg.attr('width');
var svgHeight = +svg.attr('height');

// Define a padding object
// This will space out the trellis subplots
var padding = {t: 20, r: 20, b: 60, l: 60};

// Compute the dimensions of the trellis plots, assuming a 2x2 layout matrix.
trellisWidth = svgWidth / 2 - padding.l - padding.r;
trellisHeight = svgHeight / 2 - padding.t - padding.b;

// As an example for how to layout elements with our variables
// Lets create .background rects for the trellis plots
svg.selectAll('.background')
    .data(['A', 'B', 'C', 'C']) // dummy data
    .enter()
    .append('rect') // Append 4 rectangles
    .attr('class', 'background')
    .attr('width', trellisWidth) // Use our trellis dimensions
    .attr('height', trellisHeight)
    .attr('transform', function(d, i) {
        // Position based on the matrix array indices.
        // i = 1 for column 1, row 0)
        var tx = (i % 2) * (trellisWidth + padding.l + padding.r) + padding.l;
        var ty = Math.floor(i / 2) * (trellisHeight + padding.t + padding.b) + padding.t;
        return 'translate('+[tx, ty]+')';a
    });

var parseDate = d3.timeParse('%b %Y');
// To speed things up, we have already computed the domains for your scales
var dateDomain = [new Date(2000, 0), new Date(2010, 2)];
var priceDomain = [0, 223.02];

// **** How to properly load data ****

d3.csv('./stock_prices.csv').then(function(dataset) {
    console.log('got csv')
    // **** Your JavaScript code goes here ****
    dataset.forEach(function (stock) {
        stock.date = parseDate(stock.date);
    });
    var nested = d3.nest()
        .key(function(stock) {
            return stock.company;
        })
        .entries(dataset);

    console.log("dataset: ", dataset);
    console.log("nested: ", nested);

    var svg = d3.select('svg');

    var companyG = svg.selectAll('.trellis')
        .data(nested)
        .enter()
        .append('g')
        .attr('class', 'trellis')
        .attr('transform', function(d,i) {
            var x = (i % 2) * (trellisWidth + padding.l + padding.r) + padding.l;
            var y = Math.floor(i / 2) * (trellisHeight + padding.t + padding.b) + padding.t;
            return 'translate('+x+','+y+')';
        });

    var xScale = d3.scaleTime() //operatinng as a function
        .domain(dateDomain)
        .range([0, trellisWidth]); 
    var yScale = d3.scaleLinear()
        .domain(priceDomain)
        .range([trellisHeight, 0]);

    var lineInterpolate = d3.line()
        .x(function(d) {
            return xScale(d.date);
        })
        .y(function(d) {
            return yScale(d.price);
        });
    
    // nested.forEach(function(d, i) {
    //     console.log([d.values])
        // companyG.append('path')
        // .attr('class', 'line-plot')
        // .enter()
        // .data([d.values])
        // .attr('d', lineInterpolate)
        // .attr('stroke', '#333');

        // companyG.selectAll('.path')
        // .data([d.values])
        // .enter()
        // .append('path')
    // });

    var colorScale = d3.scaleOrdinal(d3.schemeCategory10) //won't work?
    .domain(nested.map(function(d) {
        return d.key;
    }));

    var plot = companyG.selectAll('line-plot')
        .data(function(d, i) {
            return [d.values];
        })
        .enter()
        .append('path')
        .attr('class', 'line-plot')
        .attr('d', lineInterpolate)
        .attr('stroke', '#333')
        .attr('stroke', function(d,i){
            console.log("d", d[0]);
            return colorScale(d[0].company);
        });

    var xAxis = d3.axisBottom(xScale);
    var yAxis = d3.axisLeft(yScale);

    var xPlot = companyG.append('g')
        .attr('class', 'x-axis')
        .attr('transform', 'translate(0,'+trellisHeight+')')
        .call(xAxis);
    
    var yPlot = companyG.append('g')
        .attr('class', 'y-axis')
        .attr('transform', 'translate(0,0)')
        .call(yAxis);
     

});


// Remember code outside of the data callback function will run before the data loads