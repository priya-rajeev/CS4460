
d3.csv('./baseball_hr_leaders_2017.csv').then(function(dataset) {
	console.log("This is working");
	console.log(dataset[0]);

	dataset.forEach(function(player) {
		player.rank =+ player.rank;
		player.year =+ player.year;
		player.homeruns =+ player.homeruns;
	});

	console.log(dataset[0]);

	var name = [];
	var rank = [];
	var year = [];
	var homeruns = [];
	var i = 0;

	dataset.forEach(function(player) {
		name[i] = player['name'];
		rank[i] = player['rank'];
		year[i] = player['year'];
		homeruns[i] = player['homeruns'];
		i++;
	});

	i = 0;

	// dataset.forEach(function(player) {
	// 	console.log(player['name']);
	// 	var p = d3.select("body").selectAll("p")
	// 	.data(player['name'])
	// 	.enter()
	// 	.append("p")
	// 	.text(name[i]);
	// });

	var p = d3.select("#homerun-leaders")
	.selectAll("p")
	.data(dataset)
	.enter()
	.append("p")
	.text(function(player,i) {
		return i + 1 + ". " + player['name'] + " with " + player['homeruns'] + " home runs"
	})
	.style("font-weight", function(player, i) {
		if (player['name'] == 'Giancarlo Stanton') {
			return 'bold';
		} else{
			return 'normal';
		}
	});

	var tr = d3.select("tbody")
	.selectAll("tr")
	.data(dataset)
	.enter()
	.append("tr");
	// .text(function(player,i) {
	// 	return player['rank'] + player['name']
	// });

	var td = tr.selectAll("td")
	.data(function (player, i) {    // joins inner array of each row
		var arr = []
		arr.push(player['name'])
		arr.unshift(player['rank'])
		arr.push(player['homeruns'])
		return arr
	})
	.enter()    // create placeholders for each element in an inner array
	.append("td") // creates <td> in each placeholder
	.text(function (player, i) {
		console.log(player)
		return player;
	});
	
});


// **** Your JavaScript code goes here ****
